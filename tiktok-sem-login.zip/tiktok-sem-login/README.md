# TikTok sem pop-up de login

Extensão para o Google Chrome que esconde o pop-up de login do TikTok,
para você assistir aos vídeos sem precisar de uma conta.

## O que ela faz

- Esconde o pop-up de login que aparece sobre os vídeos.
- Fecha o pop-up automaticamente quando ele tem botão de fechar.
- Remove a camada escura/invisível que fica por cima da tela e impede os cliques.
- Devolve a rolagem da página, que o pop-up costuma travar.

## Arquivos

| Arquivo | Para que serve |
|---|---|
| `manifest.json` | Configuração da extensão (nome, versão e em quais sites roda). |
| `content.js` | Script que detecta e esconde o pop-up e as camadas que bloqueiam a tela. |
| `content.css` | Regras de estilo que escondem o pop-up logo que a página carrega. |
| `README.md` | Este arquivo. |

## Como instalar

1. Extraia o `.zip` em uma pasta.
2. No Chrome, abra `chrome://extensions`.
3. Ative o **Modo do desenvolvedor** (canto superior direito).
4. Clique em **Carregar sem compactação** e selecione a pasta `tiktok-sem-login`.
5. Abra o `tiktok.com` e recarregue a página (F5).

Funciona também em navegadores baseados em Chromium (Edge, Brave, Opera).

## Como atualizar

Ao receber uma nova versão, substitua os arquivos da pasta, vá em
`chrome://extensions` e clique no ícone de recarregar da extensão.
Depois recarregue a aba do TikTok.

## Problemas comuns

**Não consigo clicar em nada depois de um tempo.**
Atualize para a versão 1.1 ou mais nova. Ela remove a camada invisível
que o pop-up deixava na tela.

**O pop-up voltou a aparecer.**
O TikTok muda os nomes internos dos elementos com frequência, então os
seletores podem ficar desatualizados. Nesse caso, a extensão precisa de ajuste.

**Curtir, comentar e seguir não funcionam.**
Essas ações exigem conta e são bloqueadas pelo servidor do TikTok.
A extensão não muda isso.

**Não funciona no celular.**
O Chrome para Android não aceita extensões. Use um navegador que aceite,
como o Kiwi Browser ou o Firefox para Android.

## Limitações

- Funciona só em `tiktok.com`.
- Não burla restrições do servidor (vídeos privados ou com restrição de idade).
- Depende da estrutura atual do site, que pode mudar sem aviso.

## Aviso

Projeto de uso pessoal, sem vínculo com o TikTok ou a ByteDance.
