(function () {
  const LOGIN_TEXT = /(log in to tiktok|entrar no tiktok|continue with|continuar com|use phone|usar telefone|sign up|cadastre|inscreva-se)/i;

  const POPUP_SELECTORS = [
    '#login-modal',
    '[data-e2e="login-modal"]',
    '[data-e2e="login-modal-mask"]',
    '[class*="DivLoginContainer"]',
    '[class*="LoginModal"]'
  ].join(',');

  function hide(el) {
    el.style.setProperty('display', 'none', 'important');
    el.style.setProperty('pointer-events', 'none', 'important');
  }

  // 1) Pop-ups de login conhecidos (por seletor)
  function hideKnownPopups() {
    document.querySelectorAll(POPUP_SELECTORS).forEach((el) => {
      const closeBtn = el.querySelector(
        '[data-e2e="modal-close-inner-button"], [aria-label="Close"], [aria-label="Fechar"]'
      );
      if (closeBtn) closeBtn.click();
      hide(el);
    });
  }

  // 2) Camadas fixas que cobrem a tela inteira (máscara invisível que bloqueia cliques)
  function hideBlockingOverlays() {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const points = [
      [vw / 2, vh / 2], [vw / 4, vh / 2], [vw * 0.75, vh / 2],
      [vw / 2, vh / 4], [vw / 2, vh * 0.75]
    ];

    points.forEach(([x, y]) => {
      document.elementsFromPoint(x, y).forEach((el) => {
        if (el === document.body || el === document.documentElement) return;
        const style = getComputedStyle(el);
        if (style.position !== 'fixed') return;

        const rect = el.getBoundingClientRect();
        if (rect.width < vw * 0.9 || rect.height < vh * 0.9) return;

        // nunca mexe em algo que contenha vídeo (player / visualização de vídeo)
        if (el.querySelector('video')) return;

        const text = (el.innerText || '').trim();
        const isEmptyMask = text.length < 5;
        const isLoginPopup = LOGIN_TEXT.test(text.slice(0, 800));

        if (isEmptyMask || isLoginPopup) hide(el);
      });
    });
  }

  // 3) Devolve rolagem e remove bloqueios de foco
  function restorePage() {
    document.querySelectorAll('[inert]').forEach((el) => el.removeAttribute('inert'));
    [document.documentElement, document.body].forEach((el) => {
      if (!el) return;
      el.style.setProperty('overflow', 'auto', 'important');
      el.style.setProperty('pointer-events', 'auto', 'important');
    });
  }

  function run() {
    try {
      hideKnownPopups();
      hideBlockingOverlays();
      restorePage();
    } catch (e) { /* ignora erros para não quebrar a página */ }
  }

  let timer = null;
  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(run, 150);
  }

  function start() {
    new MutationObserver(schedule).observe(document.documentElement, {
      childList: true,
      subtree: true
    });
    // checagem extra de tempos em tempos (o pop-up costuma aparecer "depois de um tempo")
    setInterval(run, 2000);
    run();
  }

  if (document.documentElement) start();
  else document.addEventListener('DOMContentLoaded', start);
})();
